1. 从函数依赖集F中选择一个不满足BCNF的函数依赖,α → β 分解关系模式R
	1. R1={α , β}, R2 = R-β
	2. 构造出的R1上, α → β能满足BCNF
2. 在R2上, 求所有**属性组合的闭包**, (**这个闭包可以使用所有F, 求完闭包再映射属性闭包到R2**)
	- 如R2=ABC
		- A->A,B->B,C->CEG,AB->AB,BC->BCEG,AC->ABCEG
		- A->A,B->B,**C->CEG**,AB->AB是平凡的
			- 因为在R2上, 没有EG, C->CEG相当于C->C
		- BC->BCEG是违背BCNF范式的
		- AC->ABCEG, AC是超键
	- 闭包中的所有依赖, 要么是[[平凡依赖]], 要么左边是超键
	- 如果有不是的, 则该函数依赖违背BCNF范式, 以该函数依赖α → β分解关系模式R2
	- 重新执行步骤1

BCNF分解到的分解一定是[[无损分解（Lossless Decomposition）的判定|无损连接]]的, 但不一定[[保持函数依赖(Dependency Preservation)]]