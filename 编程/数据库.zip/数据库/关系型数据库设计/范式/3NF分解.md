1. 得到[[规范覆盖]]Fc, 和[[键#2. ​**​候选键（Candidate Key）​**​]]
2. 将Fc中的每一项作为一个关系
	1. 如Fc={A->B,C->D}, 则分解p={{A,B},{C,D}}
3. 如过p不包含任意一个候选键, 那么添加**任意一个就行**
4. 如果p中有Ri$\subset$Rj, 删除Ri


3NF分解得到的分解一定是[[无损分解（Lossless Decomposition）的判定]], 也一定能[[保持函数依赖(Dependency Preservation)]]
